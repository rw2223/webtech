const memberForm = document.getElementById('member-form');
const nameInput = document.getElementById('name');
const ageInput = document.getElementById('age');
const memberList = document.getElementById('member-list');

const members = [];

memberForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const name = nameInput.value;
    const age = parseInt(ageInput.value);

    if (name && age) {
        const member = {
            id: Date.now(),
            name,
            age
        };

        members.push(member);
        displayMembers();
        memberForm.reset();
    }
});

function displayMembers() {
    memberList.innerHTML = '';

    members.forEach(member => {
        const li = document.createElement('li');
        li.innerHTML = `
            <strong>${member.name}</strong> - ${member.age} years old
            <button onclick="editMember(${member.id})">Edit</button>
            <button onclick="deleteMember(${member.id})">Delete</button>
        `;
        memberList.appendChild(li);
    });
}

function deleteMember(id) {
    const index = members.findIndex(member => member.id === id);

    if (index !== -1) {
        members.splice(index, 1);
        displayMembers();
    }
}

function editMember(id) {
    const index = members.findIndex(member => member.id === id);

    if (index !== -1) {
        const member = members[index];
        const newName = prompt('Enter new name:', member.name);
        const newAge = parseInt(prompt('Enter new age:', member.age));

        if (newName && newAge) {
            member.name = newName;
            member.age = newAge;
            displayMembers();
        }
    }
}

displayMembers();
